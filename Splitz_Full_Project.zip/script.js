let selectedMembers=[];

function addMember(){
 const i=document.createElement('input');
 i.className='member';
 i.placeholder='Nama Anggota';
 document.getElementById('members').appendChild(i);
}

function saveGroup(){
 const name=document.getElementById('groupName').value;
 const members=[...document.querySelectorAll('.member')].map(x=>x.value).filter(Boolean);
 if(!name||members.length===0)return alert('Lengkapi data');
 const groups=JSON.parse(localStorage.getItem('groups')||'[]');
 groups.push({name,members});
 localStorage.setItem('groups',JSON.stringify(groups));
 loadGroups();
}

function loadGroups(){
 const groups=JSON.parse(localStorage.getItem('groups')||'[]');
 const box=document.getElementById('groupList');
 box.innerHTML='';
 groups.forEach(g=>{
   const d=document.createElement('div');
   d.className='group';
   d.innerHTML=`<b>${g.name}</b><br>${g.members.join(', ')}<br><button onclick='useGroup(${JSON.stringify(g).replace(/'/g,"&apos;")})'>Gunakan</button>`;
   box.appendChild(d);
 });
}

function useGroup(g){
 selectedMembers=g.members;
 renderPayments();
 alert('Grup dipilih: '+g.name);
}

function splitBill(){
 const total=Number(document.getElementById('bill').value||0);
 if(total<=0||selectedMembers.length===0) return alert('Pilih grup dan isi tagihan');
 const each=Math.round(total/selectedMembers.length);
 document.getElementById('result').innerHTML='Per orang: Rp'+each.toLocaleString('id-ID');
 const payments=selectedMembers.map(n=>({name:n,amount:each,paid:false}));
 localStorage.setItem('payments',JSON.stringify(payments));
 renderPayments();
}

function togglePay(i){
 const p=JSON.parse(localStorage.getItem('payments')||'[]');
 p[i].paid=!p[i].paid;
 localStorage.setItem('payments',JSON.stringify(p));
 renderPayments();
}

function renderPayments(){
 const p=JSON.parse(localStorage.getItem('payments')||'[]');
 const box=document.getElementById('paymentList');
 box.innerHTML='';
 p.forEach((x,i)=>{
   const d=document.createElement('div');
   d.className='person';
   d.innerHTML=`${x.name} - Rp${x.amount.toLocaleString('id-ID')} <button onclick='togglePay(${i})' class='${x.paid?"paid":"unpaid"}'>${x.paid?"Lunas":"Belum"}</button>`;
   box.appendChild(d);
 });
}
loadGroups();
renderPayments();
